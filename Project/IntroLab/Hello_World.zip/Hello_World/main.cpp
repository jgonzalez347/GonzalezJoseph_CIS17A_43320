/* 
 * File:   main.cpp
 * Author: JosephGonzalez
 *
 * Created on February 23, 2020, 7:00 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    cout << "Hello World" << endl;
    return 0;
}

